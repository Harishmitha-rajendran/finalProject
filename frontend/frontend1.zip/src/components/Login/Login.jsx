import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import './Login.css'

const Login = () => {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
//   const [emailError, setEmailError] = useState('')
//   const [passwordError, setPasswordError] = useState('')
//mongodb+srv://<username>:<password>@cluster0.hh7xl.mongodb.net/

  const navigate = useNavigate()

  const login = (e) => {
    e.preventDefault();
    console.log('Login with:', email, password);
    // Implement login functionality here
  }

  return (
    <div className='container'>
      
      <form className='form' onSubmit={(e)=>login(e)}>
        <h1>Login</h1>
         <input
          value={email}
          placeholder="Enter your email here"
          onChange={(event) => setEmail(event.target.value)}
          className='inputBox'
        />
        <input
          value={password}
          placeholder="Enter your password here"
          onChange={(event) => setPassword(event.target.value)}
          className='inputBox'
        />
        <p onClick={() => {navigate("/ForgotPassword")}}>Forgot Password ? </p>
        <button className='submitButton' type="submit" >Login</button>
      </form>

    </div>
  )
}

export default Login